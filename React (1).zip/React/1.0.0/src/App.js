import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>DOS DE LOS MEJORES ESCRITORES</h1>

      <div class="row">
  <div class="col-sm-6 mb-3 mb-sm-0">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Gabriel Garcia Márquez</h5>
        <p class="card-text"> Fue un escritor y periodista colombiano. Reconocido principalmente por sus novelas y cuentos, también escribió narrativa de no ficción, discursos, reportajes, críticas cinematográficas y memorias.</p>
        <a href="#" class="btn btn-primary">Mas Información</a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Muguel de Cervantes</h5>
        <p class="card-text"> Fue un novelista, poeta, dramaturgo y soldado español. Es ampliamente considerado una de las máximas figuras de la literatura española.</p>
        <a href="#" class="btn btn-primary">Mas Información</a>
      </div>
    </div>
  </div>
</div>
  
      </header>
    </div>
  );
}

export default App;
